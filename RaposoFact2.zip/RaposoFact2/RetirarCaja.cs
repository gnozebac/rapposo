﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace RaposoFact
{
    public partial class RetirarCaja : Form
    {
        public RetirarCaja()
        {
            InitializeComponent();
        }
    }
}
