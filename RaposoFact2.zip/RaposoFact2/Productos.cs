﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace RaposoFact
{
    public partial class Productos : Form
    {
        Clases.ClsProductos productos = new Clases.ClsProductos();
        Clases.Familia familia = new Clases.Familia();
        public Productos()
        {
            InitializeComponent();
        }

        private void txtdetalle_TextChanged(object sender, EventArgs e)
        {
            dataGridView1.DataSource = productos.cargarsuProductosTodo(txtdetalle.Text).Tables[0];
            
        }

        private void btnguardar_Click(object sender, EventArgs e)
        {
            try
            {
                if (txtpvp.Text != "")
                {

                    try
                    {
                        productos.guardar(Convert.ToString(comboBox3.SelectedValue), txtdetalle.Text, Convert.ToDecimal(txtcosto.Text), Convert.ToInt16(txtnumunidades.Text), Convert.ToDecimal(txtgastos.Text), Convert.ToInt16(txtganancia.Text), Convert.ToString(cmbtipoiva.SelectedItem), Convert.ToString(cmbtipocompra.SelectedItem), Convert.ToDecimal(txtpvp.Text), Convert.ToInt16(txtstock.Text), Convert.ToString(comboBox1.SelectedValue), txtcodbar.Text);
                   
                        dataGridView1.DataSource = productos.cargarsuProductosTodo(txtdetalle.Text).Tables[0];
                        MessageBox.Show("Guardado exitosamente");
                        limpiar();
                        btnguardar.Enabled = true;
                        btneditar.Enabled = false;
                    }
                    catch
                    {
                        MessageBox.Show("Producto ya registrado/Editar");
                    }
                }
                else
                {
                    MessageBox.Show("Calcular el Precio");
                }
            }
            catch
            { MessageBox.Show("Error"); }
        }

        private void btneditar_Click(object sender, EventArgs e)
        {
            try
            {

                productos.editarProductos(txtdetalle.Text, Convert.ToDouble(txtpvp.Text), Convert.ToDouble(txtgastos.Text), Convert.ToInt16(txtganancia.Text), Convert.ToInt16(txtstock.Text), Convert.ToString(comboBox3.SelectedValue), Convert.ToString(comboBox1.SelectedValue), Convert.ToInt16(txtnumunidades.Text), Convert.ToDecimal(txtcosto.Text), txtid.Text, Convert.ToString(cmbtipoiva.Text), Convert.ToString(cmbtipocompra.Text), txtcodbar.Text);

                MessageBox.Show("Guardado exitosamente");
                limpiar();
                btnguardar.Enabled = true;
                btneditar.Enabled = false;
            }
            catch
            { MessageBox.Show("Error"); }
        }

        private void btndescartar_Click(object sender, EventArgs e)
        {
            if

(MessageBox.Show("Seguro que dese salir?", "Salir", MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                productos.eliminarProductos(txtid.Text);
                limpiar();
            }
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            cargarhijo();
        }

        private void cmbtipoiva_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btncalcularprecio_Click(object sender, EventArgs e)
        {
            calcularprecioFactura();
            txtstock.Focus();
        }
        private void calcularprecioFactura()
        {
            try
            {
                decimal sacarcosto;
                decimal costounitario;
                decimal valoriva;
                decimal pvt;
                decimal ganan;

                if (Convert.ToString(cmbtipocompra.SelectedItem) == "Nota venta")
                {

                    pvt = Convert.ToDecimal(txtcosto.Text) + Convert.ToDecimal(txtcosto.Text) * Convert.ToDecimal(txtganancia.Text) / 100;
                    string pvp = string.Format("{0:#,#0.00}", pvt);
                    costounitario = Convert.ToDecimal(pvt) / Convert.ToDecimal(txtnumunidades.Text);
                                  string resultado = string.Format("{0:#,#0.00}", costounitario);
                                  sacarcosto = Convert.ToDecimal(resultado) + Convert.ToDecimal(txtgastos.Text);
                                  txtpvp.Text = Convert.ToString(sacarcosto);

                }
                else
                {
                    if (Convert.ToString(cmbtipocompra.SelectedItem) == "Factura")
                    {
                        if (Convert.ToString(cmbtipoiva.SelectedItem) == "12")
                        {
                            valoriva = Convert.ToDecimal(txtcosto.Text) + Convert.ToDecimal(txtcosto.Text) * Convert.ToDecimal(cmbtipoiva.SelectedItem) / 100;
                            pvt = Convert.ToDecimal(valoriva) + Convert.ToDecimal(valoriva) * Convert.ToDecimal(txtganancia.Text) / 100;
                            //ganan = pvt * Convert.ToDecimal(txtganancia.Text);
                            textBox2.Text = Convert.ToString(valoriva);
                           costounitario = Convert.ToDecimal(pvt) / Convert.ToDecimal(txtnumunidades.Text);
                            string pvu = string.Format("{0:#,#0.00}", costounitario);
                            sacarcosto = Convert.ToDecimal(pvu) + Convert.ToDecimal(txtgastos.Text);
                            string resultado = string.Format("{0:#,#0.00}", sacarcosto);

                            txtpvp.Text = Convert.ToString(resultado);
                            
                  
                        }
                        if (Convert.ToString(cmbtipoiva.SelectedItem) == "0")
                        {
                            pvt = Convert.ToDecimal(txtcosto.Text) + Convert.ToDecimal(txtcosto.Text) * Convert.ToDecimal(txtganancia.Text) / 100;
                         
                            costounitario = Convert.ToDecimal(pvt) / Convert.ToDecimal(txtnumunidades.Text);
                            string pvu = string.Format("{0:#,#0.00}", costounitario);
                            sacarcosto = Convert.ToDecimal(pvu) + Convert.ToDecimal(txtgastos.Text);
                            string resultado = string.Format("{0:#,#0.00}", sacarcosto);

                            txtpvp.Text = Convert.ToString(resultado);
                            
                        }

                    }
                }

            }
            catch
            {
            }
        }

        private void txtcosto_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                e.Handled = true;
                //txtFecha.Focus();
            }
            else if (e.KeyChar == '.')
            {
                // si se pulsa en el punto se convertirá en coma
                e.Handled = true;
                SendKeys.Send(",");
            }
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != 8 && e.KeyChar != 44) // Si no es numerico y si no es espacio
            {

                e.Handled = true;

                System.Media.SystemSounds.Beep.Play();
            }
        }
        private void cargarPadre()
        {

            DataSet da = new DataSet();
            da = productos.usuario();
            comboBox1.DataSource = da.Tables[0];
            comboBox1.DisplayMember = "familia";
            comboBox1.ValueMember = "idfamilia";

        }
        private void cargarhijo()
        {
            DataSet da = new DataSet();
            da = productos.cargarsubfamilia(Convert.ToString(comboBox1.SelectedValue));
            comboBox3.DataSource = da.Tables[0];
            comboBox3.DisplayMember = "subfamilia";
            comboBox3.ValueMember = "idfamilia";

        }
        private void limpiar()
        {
            txtdetalle.Text = "";
            txtpvp.Text = "";
            txtid.Focus();
            txtstock.Text = "1";
            txtnumunidades.Text = "1";
            txtganancia.Text = "45";
            txtgastos.Text = "0";
            txtcosto.Text = "0";
            txtid.Text = "";
            txtcodbar.Text = "";
        }

        private void Productos_Load(object sender, EventArgs e)
        {
            txtpvp.Text = String.Format(txtpvp.Text, "#.##");

            cargarPadre();
            cargarhijo();
            btnguardar.Enabled = false;
            btneditar.Enabled = false;
        }

        private void txtdetalle_TextChanged_1(object sender, EventArgs e)
        {
            dataGridView1.DataSource = productos.cargarsuProductosTodo(txtdetalle.Text).Tables[0];
        }

        private void dataGridView1_Click(object sender, EventArgs e)
        {
            try
            {
                btnguardar.Enabled = false;
                btneditar.Enabled = true;
                txtid.Text = dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[0].Value.ToString();
                comboBox3.SelectedValue = dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[11].Value.ToString();
                comboBox1.SelectedValue = dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[12].Value.ToString();

                txtdetalle.Text = dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[2].Value.ToString();
                txtcosto.Text = dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[5].Value.ToString();
                txtnumunidades.Text = dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[7].Value.ToString();
                txtgastos.Text = dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[8].Value.ToString();
                txtganancia.Text = dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[6].Value.ToString();
                cmbtipoiva.SelectedItem = dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[9].Value.ToString();
                cmbtipocompra.SelectedItem = dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[10].Value.ToString();
                txtpvp.Text = dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[3].Value.ToString();
                txtstock.Text = dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[4].Value.ToString();
                txtcodbar.Text = dataGridView1.Rows[dataGridView1.CurrentRow.Index].Cells[13].Value.ToString();
            }
            catch
            { }
        }

        private void btgnnuevo_Click(object sender, EventArgs e)
        {
            limpiar();
            btnguardar.Enabled = true;
            btneditar.Enabled = false;
        }

        private void txtgastos_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == '\r')
            {
                e.Handled = true;
                //txtFecha.Focus();
            }
            else if (e.KeyChar == '.')
            {
                // si se pulsa en el punto se convertirá en coma
                e.Handled = true;
                SendKeys.Send(",");
            }
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != 8 && e.KeyChar != 44) // Si no es numerico y si no es espacio
            {

                e.Handled = true;

                System.Media.SystemSounds.Beep.Play();
            }
        }

        private void txtid_KeyPress(object sender, KeyPressEventArgs e)
        {
          
            
        }

        private void txtid_TextChanged(object sender, EventArgs e)
        {
            try
            {

                Clases.Clsfactura factura = new Clases.Clsfactura();


                dataGridView1.DataSource = productos.cargarsuProductosTodoxcod(txtid.Text).Tables[0];
                
            }
            catch { }
        }

        private void txtganancia_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtcodbar_TextChanged(object sender, EventArgs e)
    
        {


            dataGridView1.DataSource = productos.cargarsuProductosTodocodbar(this.txtcodbar.Text).Tables[0];
           
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void txtganancia_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != 8) // Si no es numerico y si no es espacio
            {

                e.Handled = true; 

                System.Media.SystemSounds.Beep.Play();
            }
        }

        private void txtstock_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != 8) // Si no es numerico y si no es espacio
            {

                e.Handled = true;

                System.Media.SystemSounds.Beep.Play();
            }
        }

        private void txtnumunidades_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && e.KeyChar != 8) // Si no es numerico y si no es espacio
            {

                e.Handled = true;

                System.Media.SystemSounds.Beep.Play();
            }
        }

        private void txtcosto_TextChanged(object sender, EventArgs e)
        {

        }


 
    }
}
