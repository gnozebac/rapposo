﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace RaposoFact.Clases
{
    public partial class FrmCrtRepstock0 : Form
    {
        public FrmCrtRepstock0()
        {
            InitializeComponent();
        }
    }
}
