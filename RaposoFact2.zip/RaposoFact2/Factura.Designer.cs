﻿namespace RaposoFact
{
    partial class Factura
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Factura));
            this.btnproducto = new System.Windows.Forms.Button();
            this.btnselecccionar = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtcodigobarras = new System.Windows.Forms.TextBox();
            this.txtaux = new System.Windows.Forms.TextBox();
            this.txtcsiva = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtstock = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.button4 = new System.Windows.Forms.Button();
            this.label21 = new System.Windows.Forms.Label();
            this.btneliminar = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.btnguardar = new System.Windows.Forms.Button();
            this.txttotal = new System.Windows.Forms.TextBox();
            this.txtproducto = new System.Windows.Forms.TextBox();
            this.txtprecio = new System.Windows.Forms.TextBox();
            this.txtcodigo = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtcantidad = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.txtiva12 = new System.Windows.Forms.TextBox();
            this.txtiva0 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.txtiva = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.txtsubtotal = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.txtcambio = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.txtefectivo = new System.Windows.Forms.TextBox();
            this.txttotalg = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.dgFac = new System.Windows.Forms.DataGridView();
            this.cuenta = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cantidad = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descripcion = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.vu = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iva = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label24 = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtnumfac = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btncliente = new System.Windows.Forms.Button();
            this.txtfono = new System.Windows.Forms.TextBox();
            this.label33 = new System.Windows.Forms.Label();
            this.txtdireccion = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.txtidcliente = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtbuscar = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.panel2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgFac)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnproducto
            // 
            this.btnproducto.Location = new System.Drawing.Point(592, 11);
            this.btnproducto.Name = "btnproducto";
            this.btnproducto.Size = new System.Drawing.Size(21, 20);
            this.btnproducto.TabIndex = 32;
            this.btnproducto.Text = "::";
            this.btnproducto.UseVisualStyleBackColor = true;
            this.btnproducto.Visible = false;
            // 
            // btnselecccionar
            // 
            this.btnselecccionar.Location = new System.Drawing.Point(592, 448);
            this.btnselecccionar.Name = "btnselecccionar";
            this.btnselecccionar.Size = new System.Drawing.Size(75, 23);
            this.btnselecccionar.TabIndex = 50;
            this.btnselecccionar.Text = "Seleccionar";
            this.btnselecccionar.UseVisualStyleBackColor = true;
            this.btnselecccionar.Click += new System.EventHandler(this.btnselecccionar_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Control;
            this.panel2.Controls.Add(this.txtcodigobarras);
            this.panel2.Controls.Add(this.txtaux);
            this.panel2.Controls.Add(this.txtcsiva);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.txtstock);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.button4);
            this.panel2.Controls.Add(this.label21);
            this.panel2.Controls.Add(this.btnproducto);
            this.panel2.Controls.Add(this.btneliminar);
            this.panel2.Controls.Add(this.label17);
            this.panel2.Controls.Add(this.btnguardar);
            this.panel2.Controls.Add(this.txttotal);
            this.panel2.Controls.Add(this.txtproducto);
            this.panel2.Controls.Add(this.txtprecio);
            this.panel2.Controls.Add(this.txtcodigo);
            this.panel2.Controls.Add(this.label22);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.txtcantidad);
            this.panel2.Controls.Add(this.label23);
            this.panel2.Location = new System.Drawing.Point(12, 105);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(660, 100);
            this.panel2.TabIndex = 48;
            // 
            // txtcodigobarras
            // 
            this.txtcodigobarras.Location = new System.Drawing.Point(55, 59);
            this.txtcodigobarras.Name = "txtcodigobarras";
            this.txtcodigobarras.Size = new System.Drawing.Size(100, 20);
            this.txtcodigobarras.TabIndex = 86;
            this.txtcodigobarras.TextChanged += new System.EventHandler(this.txtcodigobarras_TextChanged);
            this.txtcodigobarras.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcodigobarras_KeyPress);
            // 
            // txtaux
            // 
            this.txtaux.Location = new System.Drawing.Point(403, 59);
            this.txtaux.Name = "txtaux";
            this.txtaux.Size = new System.Drawing.Size(79, 20);
            this.txtaux.TabIndex = 85;
            this.txtaux.Visible = false;
            // 
            // txtcsiva
            // 
            this.txtcsiva.Location = new System.Drawing.Point(434, 34);
            this.txtcsiva.Name = "txtcsiva";
            this.txtcsiva.ReadOnly = true;
            this.txtcsiva.Size = new System.Drawing.Size(48, 20);
            this.txtcsiva.TabIndex = 84;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(383, 40);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 13);
            this.label2.TabIndex = 83;
            this.label2.Text = "I.V.A.:";
            // 
            // txtstock
            // 
            this.txtstock.Location = new System.Drawing.Point(488, 59);
            this.txtstock.Name = "txtstock";
            this.txtstock.ReadOnly = true;
            this.txtstock.Size = new System.Drawing.Size(42, 20);
            this.txtstock.TabIndex = 81;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(488, 39);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 82;
            this.label1.Text = "Stock:";
            // 
            // button4
            // 
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Image = global::RaposoFact.Properties.Resources.cancel;
            this.button4.Location = new System.Drawing.Point(619, 69);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(36, 28);
            this.button4.TabIndex = 60;
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(280, 38);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(34, 13);
            this.label21.TabIndex = 58;
            this.label21.Text = "Total:";
            this.label21.Visible = false;
            // 
            // btneliminar
            // 
            this.btneliminar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btneliminar.Image = global::RaposoFact.Properties.Resources.delete;
            this.btneliminar.Location = new System.Drawing.Point(619, 38);
            this.btneliminar.Name = "btneliminar";
            this.btneliminar.Size = new System.Drawing.Size(38, 29);
            this.btneliminar.TabIndex = 59;
            this.btneliminar.UseVisualStyleBackColor = true;
            this.btneliminar.Click += new System.EventHandler(this.btneliminar_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.SystemColors.Control;
            this.label17.Location = new System.Drawing.Point(125, 11);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(66, 13);
            this.label17.TabIndex = 31;
            this.label17.Text = "Descripción:";
            // 
            // btnguardar
            // 
            this.btnguardar.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnguardar.Image = global::RaposoFact.Properties.Resources.money_dollar;
            this.btnguardar.Location = new System.Drawing.Point(619, 8);
            this.btnguardar.Name = "btnguardar";
            this.btnguardar.Size = new System.Drawing.Size(38, 30);
            this.btnguardar.TabIndex = 80;
            this.btnguardar.UseVisualStyleBackColor = true;
            this.btnguardar.Click += new System.EventHandler(this.btnguardar_Click);
            // 
            // txttotal
            // 
            this.txttotal.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txttotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttotal.ForeColor = System.Drawing.Color.Red;
            this.txttotal.Location = new System.Drawing.Point(320, 35);
            this.txttotal.Name = "txttotal";
            this.txttotal.ReadOnly = true;
            this.txttotal.Size = new System.Drawing.Size(55, 20);
            this.txttotal.TabIndex = 57;
            this.txttotal.Text = "0";
            this.txttotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txttotal.Visible = false;
            this.txttotal.TextChanged += new System.EventHandler(this.txttotal_TextChanged);
            // 
            // txtproducto
            // 
            this.txtproducto.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtproducto.Location = new System.Drawing.Point(192, 9);
            this.txtproducto.Name = "txtproducto";
            this.txtproducto.Size = new System.Drawing.Size(331, 20);
            this.txtproducto.TabIndex = 60;
            this.txtproducto.TextChanged += new System.EventHandler(this.txtproducto_TextChanged);
            this.txtproducto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtproducto_KeyPress);
            // 
            // txtprecio
            // 
            this.txtprecio.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtprecio.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtprecio.ForeColor = System.Drawing.Color.Red;
            this.txtprecio.Location = new System.Drawing.Point(197, 35);
            this.txtprecio.Name = "txtprecio";
            this.txtprecio.Size = new System.Drawing.Size(56, 20);
            this.txtprecio.TabIndex = 7;
            this.txtprecio.Text = "0";
            this.txtprecio.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtprecio.TextChanged += new System.EventHandler(this.txtprecio_TextChanged);
            this.txtprecio.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtprecio_KeyPress);
            // 
            // txtcodigo
            // 
            this.txtcodigo.Location = new System.Drawing.Point(55, 8);
            this.txtcodigo.Name = "txtcodigo";
            this.txtcodigo.Size = new System.Drawing.Size(66, 20);
            this.txtcodigo.TabIndex = 5;
            this.txtcodigo.TextChanged += new System.EventHandler(this.txtcodigo_TextChanged);
            this.txtcodigo.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcodigo_KeyPress);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.SystemColors.Control;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(13, 38);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(32, 13);
            this.label22.TabIndex = 56;
            this.label22.Text = "Cant:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(2, 11);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(43, 13);
            this.label11.TabIndex = 0;
            this.label11.Text = "Código:";
            // 
            // txtcantidad
            // 
            this.txtcantidad.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcantidad.Location = new System.Drawing.Point(55, 33);
            this.txtcantidad.MaxLength = 100;
            this.txtcantidad.Name = "txtcantidad";
            this.txtcantidad.Size = new System.Drawing.Size(66, 20);
            this.txtcantidad.TabIndex = 6;
            this.txtcantidad.Text = " 1";
            this.txtcantidad.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.txtcantidad.TextChanged += new System.EventHandler(this.txtcantidad_TextChanged);
            this.txtcantidad.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcantidad_KeyPress);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(151, 39);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(40, 13);
            this.label23.TabIndex = 55;
            this.label23.Text = "Precio:";
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.txtiva12);
            this.groupBox5.Controls.Add(this.txtiva0);
            this.groupBox5.Controls.Add(this.label4);
            this.groupBox5.Controls.Add(this.label3);
            this.groupBox5.Controls.Add(this.label29);
            this.groupBox5.Controls.Add(this.txtiva);
            this.groupBox5.Controls.Add(this.label28);
            this.groupBox5.Controls.Add(this.txtsubtotal);
            this.groupBox5.Controls.Add(this.button5);
            this.groupBox5.Controls.Add(this.label25);
            this.groupBox5.Controls.Add(this.label26);
            this.groupBox5.Controls.Add(this.label27);
            this.groupBox5.Controls.Add(this.txtcambio);
            this.groupBox5.Controls.Add(this.textBox1);
            this.groupBox5.Controls.Add(this.button6);
            this.groupBox5.Controls.Add(this.txtefectivo);
            this.groupBox5.Controls.Add(this.txttotalg);
            this.groupBox5.Location = new System.Drawing.Point(17, 422);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(573, 130);
            this.groupBox5.TabIndex = 70;
            this.groupBox5.TabStop = false;
            // 
            // txtiva12
            // 
            this.txtiva12.Location = new System.Drawing.Point(90, 46);
            this.txtiva12.Name = "txtiva12";
            this.txtiva12.Size = new System.Drawing.Size(77, 20);
            this.txtiva12.TabIndex = 94;
            this.txtiva12.Text = "0";
            // 
            // txtiva0
            // 
            this.txtiva0.Location = new System.Drawing.Point(90, 20);
            this.txtiva0.Name = "txtiva0";
            this.txtiva0.Size = new System.Drawing.Size(77, 20);
            this.txtiva0.TabIndex = 93;
            this.txtiva0.Text = "0";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(6, 54);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 16);
            this.label4.TabIndex = 92;
            this.label4.Text = "I.V.A. 12% :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(66, 16);
            this.label3.TabIndex = 91;
            this.label3.Text = "I.V.A. 0% :";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(-2, 100);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(81, 16);
            this.label29.TabIndex = 73;
            this.label29.Text = "IMPUESTO:";
            // 
            // txtiva
            // 
            this.txtiva.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtiva.Location = new System.Drawing.Point(91, 100);
            this.txtiva.Name = "txtiva";
            this.txtiva.Size = new System.Drawing.Size(76, 22);
            this.txtiva.TabIndex = 72;
            this.txtiva.Text = "0";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(12, 75);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(60, 16);
            this.label28.TabIndex = 71;
            this.label28.Text = "Subtotal:";
            // 
            // txtsubtotal
            // 
            this.txtsubtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsubtotal.Location = new System.Drawing.Point(90, 72);
            this.txtsubtotal.Name = "txtsubtotal";
            this.txtsubtotal.Size = new System.Drawing.Size(77, 22);
            this.txtsubtotal.TabIndex = 70;
            this.txtsubtotal.Text = "0";
            // 
            // button5
            // 
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.Location = new System.Drawing.Point(442, 51);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(35, 53);
            this.button5.TabIndex = 11;
            this.button5.Text = "1";
            this.button5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(184, 83);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(62, 16);
            this.label25.TabIndex = 6;
            this.label25.Text = "CAMBIO:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(184, 56);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(77, 16);
            this.label26.TabIndex = 5;
            this.label26.Text = "EFECTIVO:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(172, 20);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(52, 16);
            this.label27.TabIndex = 4;
            this.label27.Text = "TOTAL";
            // 
            // txtcambio
            // 
            this.txtcambio.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcambio.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.txtcambio.Location = new System.Drawing.Point(267, 79);
            this.txtcambio.Name = "txtcambio";
            this.txtcambio.ReadOnly = true;
            this.txtcambio.Size = new System.Drawing.Size(77, 22);
            this.txtcambio.TabIndex = 3;
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(214, 87);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(10, 22);
            this.textBox1.TabIndex = 2;
            // 
            // button6
            // 
            this.button6.Image = global::RaposoFact.Properties.Resources.money_dollar;
            this.button6.Location = new System.Drawing.Point(350, 46);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(64, 61);
            this.button6.TabIndex = 8;
            this.button6.Text = "1";
            this.button6.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // txtefectivo
            // 
            this.txtefectivo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtefectivo.Location = new System.Drawing.Point(267, 51);
            this.txtefectivo.Name = "txtefectivo";
            this.txtefectivo.Size = new System.Drawing.Size(77, 22);
            this.txtefectivo.TabIndex = 9;
            this.txtefectivo.TextChanged += new System.EventHandler(this.txtefectivo_TextChanged);
            // 
            // txttotalg
            // 
            this.txttotalg.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txttotalg.ForeColor = System.Drawing.Color.Red;
            this.txttotalg.Location = new System.Drawing.Point(233, 19);
            this.txttotalg.Name = "txttotalg";
            this.txttotalg.Size = new System.Drawing.Size(76, 26);
            this.txttotalg.TabIndex = 90;
            this.txttotalg.Text = "0";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(592, 476);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(99, 53);
            this.button2.TabIndex = 95;
            this.button2.Text = "2";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(588, 343);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(173, 87);
            this.dataGridView2.TabIndex = 72;
            this.dataGridView2.Visible = false;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(560, 237);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(201, 34);
            this.dataGridView1.TabIndex = 71;
            this.dataGridView1.Visible = false;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // dgFac
            // 
            this.dgFac.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgFac.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.cuenta,
            this.cantidad,
            this.descripcion,
            this.vu,
            this.total,
            this.iva});
            this.dgFac.Location = new System.Drawing.Point(13, 211);
            this.dgFac.Name = "dgFac";
            this.dgFac.Size = new System.Drawing.Size(748, 219);
            this.dgFac.TabIndex = 1;
            this.dgFac.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgFac_CellContentClick);
            this.dgFac.CellEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgFac_CellEnter);
            this.dgFac.CellLeave += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgFac_CellLeave);
            this.dgFac.CellMouseEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgFac_CellMouseEnter);
            this.dgFac.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.dgFac_EditingControlShowing);
            this.dgFac.RowLeave += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgFac_RowLeave);
            this.dgFac.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.dgFac_KeyPress);
            this.dgFac.KeyUp += new System.Windows.Forms.KeyEventHandler(this.dgFac_KeyUp);
            // 
            // cuenta
            // 
            this.cuenta.FillWeight = 30F;
            this.cuenta.HeaderText = "Codigo";
            this.cuenta.Name = "cuenta";
            this.cuenta.Width = 60;
            // 
            // cantidad
            // 
            this.cantidad.FillWeight = 75F;
            this.cantidad.HeaderText = "Cantidad";
            this.cantidad.Name = "cantidad";
            this.cantidad.Width = 65;
            // 
            // descripcion
            // 
            this.descripcion.FillWeight = 300F;
            this.descripcion.HeaderText = "Descripcion";
            this.descripcion.Name = "descripcion";
            this.descripcion.Width = 300;
            // 
            // vu
            // 
            this.vu.FillWeight = 75F;
            this.vu.HeaderText = "V.U.";
            this.vu.Name = "vu";
            this.vu.Width = 65;
            // 
            // total
            // 
            this.total.HeaderText = "Total";
            this.total.Name = "total";
            // 
            // iva
            // 
            this.iva.HeaderText = "IVA";
            this.iva.Name = "iva";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtnumfac);
            this.groupBox1.Location = new System.Drawing.Point(603, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(164, 87);
            this.groupBox1.TabIndex = 73;
            this.groupBox1.TabStop = false;
            // 
            // label24
            // 
            this.label24.Location = new System.Drawing.Point(13, 13);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(151, 20);
            this.label24.TabIndex = 66;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(10, 45);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(59, 16);
            this.label5.TabIndex = 65;
            this.label5.Text = "Fac. Nº";
            // 
            // txtnumfac
            // 
            this.txtnumfac.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnumfac.ForeColor = System.Drawing.Color.Red;
            this.txtnumfac.Location = new System.Drawing.Point(68, 39);
            this.txtnumfac.Name = "txtnumfac";
            this.txtnumfac.Size = new System.Drawing.Size(90, 26);
            this.txtnumfac.TabIndex = 64;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.btncliente);
            this.groupBox2.Controls.Add(this.txtfono);
            this.groupBox2.Controls.Add(this.label33);
            this.groupBox2.Controls.Add(this.txtdireccion);
            this.groupBox2.Controls.Add(this.label32);
            this.groupBox2.Controls.Add(this.textBox8);
            this.groupBox2.Controls.Add(this.label31);
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Controls.Add(this.txtidcliente);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.txtbuscar);
            this.groupBox2.Location = new System.Drawing.Point(12, 12);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(578, 87);
            this.groupBox2.TabIndex = 74;
            this.groupBox2.TabStop = false;
            // 
            // btncliente
            // 
            this.btncliente.Location = new System.Drawing.Point(341, 61);
            this.btncliente.Name = "btncliente";
            this.btncliente.Size = new System.Drawing.Size(21, 20);
            this.btncliente.TabIndex = 79;
            this.btncliente.Text = "::";
            this.btncliente.UseVisualStyleBackColor = true;
            this.btncliente.Visible = false;
            this.btncliente.Click += new System.EventHandler(this.btncliente_Click);
            // 
            // txtfono
            // 
            this.txtfono.Location = new System.Drawing.Point(85, 63);
            this.txtfono.Name = "txtfono";
            this.txtfono.Size = new System.Drawing.Size(159, 20);
            this.txtfono.TabIndex = 74;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(12, 65);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(52, 13);
            this.label33.TabIndex = 78;
            this.label33.Text = "Teléfono:";
            // 
            // txtdireccion
            // 
            this.txtdireccion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtdireccion.Location = new System.Drawing.Point(313, 13);
            this.txtdireccion.Name = "txtdireccion";
            this.txtdireccion.Size = new System.Drawing.Size(257, 20);
            this.txtdireccion.TabIndex = 73;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(248, 18);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(55, 13);
            this.label32.TabIndex = 77;
            this.label32.Text = "Dirección:";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(79, 14);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(160, 20);
            this.textBox8.TabIndex = 71;
            this.textBox8.Text = "9999999999999";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(6, 16);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(67, 13);
            this.label31.TabIndex = 76;
            this.label31.Text = "C.I. (R.U.C.):";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.SystemColors.Control;
            this.label30.Location = new System.Drawing.Point(396, 61);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(51, 13);
            this.label30.TabIndex = 65;
            this.label30.Text = "IdCliente:";
            // 
            // txtidcliente
            // 
            this.txtidcliente.Location = new System.Drawing.Point(453, 58);
            this.txtidcliente.Name = "txtidcliente";
            this.txtidcliente.ReadOnly = true;
            this.txtidcliente.Size = new System.Drawing.Size(63, 20);
            this.txtidcliente.TabIndex = 37;
            this.txtidcliente.Text = "00213";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.Control;
            this.label9.Location = new System.Drawing.Point(10, 45);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(42, 13);
            this.label9.TabIndex = 75;
            this.label9.Text = "Cliente:";
            // 
            // txtbuscar
            // 
            this.txtbuscar.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtbuscar.Location = new System.Drawing.Point(63, 37);
            this.txtbuscar.Name = "txtbuscar";
            this.txtbuscar.Size = new System.Drawing.Size(254, 20);
            this.txtbuscar.TabIndex = 72;
            this.txtbuscar.Text = "CONSUMIDOR FINAL:";
            this.txtbuscar.TextChanged += new System.EventHandler(this.txtbuscar_TextChanged);
            this.txtbuscar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbuscar_KeyPress_1);
            // 
            // button3
            // 
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.Location = new System.Drawing.Point(703, 493);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(38, 52);
            this.button3.TabIndex = 75;
            this.button3.Text = "2";
            this.button3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // Factura
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(798, 559);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.dgFac);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.groupBox5);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.btnselecccionar);
            this.Controls.Add(this.panel2);
            this.Name = "Factura";
            this.Text = "Factura";
            this.Load += new System.EventHandler(this.Factura_Load);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgFac)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnproducto;
        private System.Windows.Forms.Button btnselecccionar;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtproducto;
        private System.Windows.Forms.TextBox txtcodigo;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button btneliminar;
        private System.Windows.Forms.Button btnguardar;
        private System.Windows.Forms.TextBox txttotal;
        private System.Windows.Forms.TextBox txtprecio;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtcantidad;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox txtcambio;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.TextBox txtefectivo;
        private System.Windows.Forms.TextBox txttotalg;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtiva;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtsubtotal;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView dgFac;
        private System.Windows.Forms.TextBox txtstock;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtcsiva;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtiva12;
        private System.Windows.Forms.TextBox txtiva0;
        private System.Windows.Forms.TextBox txtaux;
        private System.Windows.Forms.TextBox txtcodigobarras;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtnumfac;
        private System.Windows.Forms.Button btncliente;
        private System.Windows.Forms.TextBox txtfono;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox txtdireccion;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtidcliente;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtbuscar;
        private System.Windows.Forms.TextBox label24;
        private System.Windows.Forms.DataGridViewTextBoxColumn cuenta;
        private System.Windows.Forms.DataGridViewTextBoxColumn cantidad;
        private System.Windows.Forms.DataGridViewTextBoxColumn descripcion;
        private System.Windows.Forms.DataGridViewTextBoxColumn vu;
        private System.Windows.Forms.DataGridViewTextBoxColumn total;
        private System.Windows.Forms.DataGridViewTextBoxColumn iva;
        private System.Windows.Forms.Button button3;
    }
}