﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace RaposoFact
{
    public partial class Facturar : Form, IForm
    {
        public Facturar()
        {
            InitializeComponent();
        }

        #region IForm Members

        public bool LoadDataGridView(DataTable dataTableParam)
        {
           // MessageBox.Show(""+ dataTableParam.Rows[0].ItemArray[0].ToString());
            dgFac[0,nFilaSel].Value=dataTableParam.Rows[0].ItemArray[0];

                        dgFac.CurrentCell = dgFac.Rows[nFilaSel].Cells[0];
            return true;
        }



        public bool LoadDataCli(DataTable dataTableParam)
        {
            // MessageBox.Show(""+ dataTableParam.Rows[0].ItemArray[0].ToString());
            //textBox1.Text = dataTableParam.Rows[0].ItemArray[0].ToString();
            textBox2.Text = dataTableParam.Rows[0].ItemArray[1].ToString();
            //textBox3.Text = dataTableParam.Rows[0].ItemArray[2].ToString();
            //textBox4.Text = dataTableParam.Rows[0].ItemArray[3].ToString();

            return true;
        }

        #endregion

        /////*****VARIABLES PUBLICAS

        public int nFilaSel;

        ///****************************************************************************************ESCRIBIR GRILLA
        ///

        void text_KeyUp(object sender, KeyEventArgs e)
        {
            int rowIndex = ((System.Windows.Forms.DataGridViewTextBoxEditingControl)(sender)).EditingControlRowIndex;
            if (e.KeyCode == Keys.F3)
            {
                dgFac.Rows.Add();
                Form1no form2 = new Form1no();
                form2.MdiParent = this.MdiParent;
                form2.Opener = this;
                form2.Show();
                nFilaSel = rowIndex;
            }
            if (e.KeyCode == Keys.Enter)
            {
                int caseSwitch = dgFac.CurrentCell.ColumnIndex;
                switch (caseSwitch)
                {
                    case 0:
                        //MessageBox.Show(dgFac.CurrentCell.ColumnIndex.ToString());
                        Clases.Clsfactura factura = new Clases.Clsfactura();
                        //int valueEntered = Convert.ToInt32(dgFac.Rows[rowIndex - 1].Cells["cuenta"].Value);
                        string codigo = dgFac.Rows[rowIndex - 1].Cells["cuenta"].Value.ToString();
                        if (codigo == null)
                            break;
                        DataSet aa = factura.cargarProductosxcod(codigo);
                        if (aa.Tables[0].Rows.Count == 0)
                        {
                            dgFac.CurrentCell = dgFac.Rows[rowIndex - 1].Cells[0];
                            //MessageBox.Show("No existes el codigo");
                            break;
                        }
                            // dgFac.Rows[rowIndex - 1].Cells["descripcion"].Value = factura.cargarProductosxcod(codigo).Tables[0].Rows[0].ItemArray[1].ToString();
                        dgFac.Rows[rowIndex - 1].Cells["descripcion"].Value = aa.Tables[0].Rows[0].ItemArray[1].ToString();

                        dgFac.Rows[rowIndex - 1].Cells["iva"].Value = aa.Tables[0].Rows[0].ItemArray[2].ToString();
                        if (dgFac.Rows[rowIndex - 1].Cells["iva"].Value.ToString() == "12")
                        {
                            dgFac.Rows[rowIndex - 1].Cells["vu"].Value = String.Format("{0:f4}", Convert.ToDouble(aa.Tables[0].Rows[0].ItemArray[3]) / 1.12);
                        }
                        else
                        {
                            dgFac.Rows[rowIndex - 1].Cells["vu"].Value = aa.Tables[0].Rows[0].ItemArray[3].ToString();
                        }

                        //dgFac.Rows[rowIndex - 1].Cells["vu"].Value = aa.Tables[0].Rows[0].ItemArray[3].ToString();
                        //Console.WriteLine("Case 1");
                        dgFac.Rows[rowIndex - 1].Cells["cantidad"].Value = "1";
                        dgFac.CurrentCell = dgFac.Rows[rowIndex - 1].Cells[1];

                        break;
                    case 1:
                        dgFac.Rows[rowIndex - 1].Cells["total"].Value = Convert.ToDouble(dgFac.Rows[rowIndex - 1].Cells["vu"].Value) * Convert.ToDouble(dgFac.Rows[rowIndex - 1].Cells["cantidad"].Value);
                        dgFac.CurrentCell = dgFac.Rows[rowIndex - 1].Cells[3];
                        sumar();
                        //Console.WriteLine("Case 1");
                        break;
                    case 2:

                        //Console.WriteLine("Case 2");
                        break;

                    case 3:
                        dgFac.Rows[rowIndex - 1].Cells["total"].Value = Convert.ToDouble(dgFac.Rows[rowIndex - 1].Cells["vu"].Value) * Convert.ToDouble(dgFac.Rows[rowIndex - 1].Cells["cantidad"].Value);
                        dgFac.CurrentCell = dgFac.Rows[rowIndex].Cells[0];
                        sumar();
                        //Console.WriteLine("Case 2");
                        break;

                    default:
                        //Console.WriteLine("Default case");
                        break;
                }




            }
        }

        /////*****************************************************************************SUMAR grilla


        private void sumar()
        {
            try
            {

                double subtotal = 0;
                double ivacero = 0;
                double iva12 = 0;
                double total = 0;
            

                for (int i = 0; i <= dgFac.Rows.Count - 2; i++)
                {
                    // subtotal = subtotal + Convert.ToDouble(dgFac.Rows[i].Cells["total"].Value);
                 
                    if (dgFac.Rows[i].Cells["iva"].Value.ToString() == "12")
                    {
                        if (dgFac.Rows[i].Cells["total"].Value != null)
                        subtotal = subtotal + (Convert.ToDouble(dgFac.Rows[i].Cells["total"].Value) );
                    }
                    else
                    {
                        if (dgFac.Rows[i].Cells["total"].Value != null)
                        ivacero = ivacero + Convert.ToDouble(dgFac.Rows[i].Cells["total"].Value);
                    }

                }
                txtsubtotal.Text = String.Format("{0:f2}", subtotal);
                txtiva0.Text = ivacero.ToString();
                txtiva12.Text = String.Format("{0:f2}", (subtotal / 100) * 12);
                txttotalg.Text = ((subtotal * 1.12) + ivacero).ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Valores Vacios" + ex.ToString());
            }
        }

        private void dgFac_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            DataGridViewTextBoxEditingControl dText = (DataGridViewTextBoxEditingControl)e.Control;
            dText.KeyUp -= new KeyEventHandler(text_KeyUp);
            dText.KeyUp += new KeyEventHandler(text_KeyUp);
        }

        private void dgFac_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            dgFac.BeginEdit(false);
        }

        private void button1_Click(object sender, EventArgs e)
        {
         
        }

        private void dgFac_KeyPress(object sender, KeyPressEventArgs e)
        {
            MessageBox.Show("++");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //FormCliFac form2 = new FormCliFac();
            //form2.MdiParent = this.MdiParent;
            //form2.Opener = this;
            //form2.Show();
        }

        private void Facturar_Load(object sender, EventArgs e)
        {

        }

        private void dgFac_KeyUp(object sender, KeyEventArgs e)
        {

        }

   

    }
}
