﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace RaposoFact.Reportes
{
    public partial class GenerarNotaVentaDia : Form
    {

        public GenerarNotaVentaDia()
        {
            InitializeComponent();
        }
        Clases.Clsreportes reportes = new Clases.Clsreportes();
        Clases.ClsProductos productos = new Clases.ClsProductos();
        Clases.Familia familia = new Clases.Familia();
        private void button1_Click(object sender, EventArgs e)
        {
           reportes.BorrarTmpnvxfecha();
           string fecha;
            fecha = dateTimePicker1.Value.ToString("dd/MM/yyyy");
            reportes.nvxfecha(Convert.ToDateTime(fecha));

            FrVentaxdia newMDIChildForm = new FrVentaxdia();
            newMDIChildForm.MdiParent = this.MdiParent;

            newMDIChildForm.Show();
            this.Close();
        }
        private void cargarPadre()
        {

            DataSet da = new DataSet();
            da = productos.usuario();
            comboBox1.DataSource = da.Tables[0];
            comboBox1.DisplayMember = "familia";
            comboBox1.ValueMember = "idfamilia";

        }
        private void GenerarNotaVentaDia_Load(object sender, EventArgs e)
        {
            cargarPadre();
        }

        private void btnstock_Click(object sender, EventArgs e)
        {
            reportes.borrarstock0();
            Clases.FrmCrtRepstock0 newMDIChildForm = new Clases.FrmCrtRepstock0();
            reportes.insertstock0(Convert.ToString(comboBox1.SelectedValue));
            newMDIChildForm.MdiParent = this.MdiParent;

            newMDIChildForm.Show();
            this.Close();
          

        }

        private void button2_Click(object sender, EventArgs e)
        {
            reportes.borrarrepxmes();
            string fecha, fecha1;
            string id;
            //fecha = dateTimePicker1.Value.ToString("dd/MM/yyyy");
            //fecha1 = dateTimePicker2.Value.ToString("dd/MM/yyyy");
            fecha = txtfechaini.Text;
            fecha1 = txtfechafin.Text;
            id = comboBox1.SelectedValue.ToString();
            reportes.repxmes( Convert.ToDateTime(fecha), Convert.ToDateTime(fecha1));

            frmRepMes newMDIChildForm = new frmRepMes();
            newMDIChildForm.MdiParent = this.MdiParent;

            newMDIChildForm.Show();
            this.Close();
        }
    }
}
