﻿namespace RaposoFact
{
    partial class Factura_compras
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Factura_compras));
            this.btnproducto = new System.Windows.Forms.Button();
            this.btncliente = new System.Windows.Forms.Button();
            this.txtfono = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.txtemail = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.txtdireccion = new System.Windows.Forms.TextBox();
            this.label32 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.txtidcliente = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtbuscar = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtfechacaducidad = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtfecha = new System.Windows.Forms.TextBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txttotal = new System.Windows.Forms.TextBox();
            this.txtiva0 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtiva = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.txtsub12 = new System.Windows.Forms.TextBox();
            this.txtautorizacion = new System.Windows.Forms.TextBox();
            this.txtcodigo = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.txtfactura = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.CrtRepstock01 = new RaposoFact.CrtRepstock0();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.btnguardar = new System.Windows.Forms.Button();
            this.groupBox2.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // btnproducto
            // 
            this.btnproducto.Location = new System.Drawing.Point(532, 330);
            this.btnproducto.Name = "btnproducto";
            this.btnproducto.Size = new System.Drawing.Size(21, 20);
            this.btnproducto.TabIndex = 32;
            this.btnproducto.Text = "::";
            this.btnproducto.UseVisualStyleBackColor = true;
            this.btnproducto.Visible = false;
            // 
            // btncliente
            // 
            this.btncliente.Location = new System.Drawing.Point(121, 156);
            this.btncliente.Name = "btncliente";
            this.btncliente.Size = new System.Drawing.Size(49, 20);
            this.btncliente.TabIndex = 5;
            this.btncliente.Text = "::";
            this.btncliente.UseVisualStyleBackColor = true;
            this.btncliente.Visible = false;
            this.btncliente.Click += new System.EventHandler(this.btncliente_Click);
            // 
            // txtfono
            // 
            this.txtfono.Location = new System.Drawing.Point(83, 96);
            this.txtfono.Name = "txtfono";
            this.txtfono.Size = new System.Drawing.Size(159, 20);
            this.txtfono.TabIndex = 4;
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox2.Controls.Add(this.txtemail);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.btncliente);
            this.groupBox2.Controls.Add(this.txtfono);
            this.groupBox2.Controls.Add(this.label33);
            this.groupBox2.Controls.Add(this.txtdireccion);
            this.groupBox2.Controls.Add(this.label32);
            this.groupBox2.Controls.Add(this.textBox8);
            this.groupBox2.Controls.Add(this.label31);
            this.groupBox2.Controls.Add(this.label30);
            this.groupBox2.Controls.Add(this.txtidcliente);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.txtbuscar);
            this.groupBox2.Location = new System.Drawing.Point(620, 25);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(447, 199);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Proveedor";
            // 
            // txtemail
            // 
            this.txtemail.Location = new System.Drawing.Point(83, 127);
            this.txtemail.Name = "txtemail";
            this.txtemail.Size = new System.Drawing.Size(312, 20);
            this.txtemail.TabIndex = 80;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(33, 134);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 13);
            this.label4.TabIndex = 79;
            this.label4.Text = "e-mail:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(18, 107);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(52, 13);
            this.label33.TabIndex = 78;
            this.label33.Text = "Teléfono:";
            // 
            // txtdireccion
            // 
            this.txtdireccion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtdireccion.Location = new System.Drawing.Point(83, 44);
            this.txtdireccion.Name = "txtdireccion";
            this.txtdireccion.Size = new System.Drawing.Size(312, 20);
            this.txtdireccion.TabIndex = 2;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(22, 51);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(55, 13);
            this.label32.TabIndex = 77;
            this.label32.Text = "Dirección:";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(83, 21);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(160, 20);
            this.textBox8.TabIndex = 0;
            this.textBox8.TextChanged += new System.EventHandler(this.textBox8_TextChanged);
            this.textBox8.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox8_KeyPress);
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(26, 25);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(33, 13);
            this.label31.TabIndex = 76;
            this.label31.Text = "RUC:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label30.Location = new System.Drawing.Point(264, 27);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(51, 13);
            this.label30.TabIndex = 65;
            this.label30.Text = "IdCliente:";
            this.label30.Visible = false;
            // 
            // txtidcliente
            // 
            this.txtidcliente.Location = new System.Drawing.Point(332, 22);
            this.txtidcliente.Name = "txtidcliente";
            this.txtidcliente.ReadOnly = true;
            this.txtidcliente.Size = new System.Drawing.Size(63, 20);
            this.txtidcliente.TabIndex = 37;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label9.Location = new System.Drawing.Point(26, 77);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(42, 13);
            this.label9.TabIndex = 75;
            this.label9.Text = "Cliente:";
            // 
            // txtbuscar
            // 
            this.txtbuscar.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtbuscar.Location = new System.Drawing.Point(83, 70);
            this.txtbuscar.Name = "txtbuscar";
            this.txtbuscar.Size = new System.Drawing.Size(312, 20);
            this.txtbuscar.TabIndex = 3;
            this.txtbuscar.TextChanged += new System.EventHandler(this.txtbuscar_TextChanged);
            this.txtbuscar.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbuscar_KeyPress);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(29, 40);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(52, 16);
            this.label5.TabIndex = 65;
            this.label5.Text = "Fac. Nº";
            // 
            // txtfechacaducidad
            // 
            this.txtfechacaducidad.Location = new System.Drawing.Point(96, 98);
            this.txtfechacaducidad.Name = "txtfechacaducidad";
            this.txtfechacaducidad.Size = new System.Drawing.Size(88, 20);
            this.txtfechacaducidad.TabIndex = 5;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(55, 128);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(33, 13);
            this.label2.TabIndex = 83;
            this.label2.Text = "IVA0:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(49, 157);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(44, 13);
            this.label1.TabIndex = 82;
            this.label1.Text = "Sub 12:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(5, 101);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(88, 13);
            this.label21.TabIndex = 58;
            this.label21.Text = "Fech Caducidad:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.label17.Location = new System.Drawing.Point(5, 17);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(79, 13);
            this.label17.TabIndex = 31;
            this.label17.Text = "Fecha Compra:";
            // 
            // txtfecha
            // 
            this.txtfecha.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtfecha.Location = new System.Drawing.Point(96, 14);
            this.txtfecha.Name = "txtfecha";
            this.txtfecha.Size = new System.Drawing.Size(88, 20);
            this.txtfecha.TabIndex = 2;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.txttotal);
            this.panel2.Controls.Add(this.txtfechacaducidad);
            this.panel2.Controls.Add(this.txtiva0);
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.txtiva);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.label21);
            this.panel2.Controls.Add(this.btnproducto);
            this.panel2.Controls.Add(this.label27);
            this.panel2.Controls.Add(this.label17);
            this.panel2.Controls.Add(this.txtsub12);
            this.panel2.Controls.Add(this.txtfecha);
            this.panel2.Controls.Add(this.txtautorizacion);
            this.panel2.Controls.Add(this.txtcodigo);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.txtfactura);
            this.panel2.Controls.Add(this.label23);
            this.panel2.Location = new System.Drawing.Point(620, 230);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(447, 305);
            this.panel2.TabIndex = 76;
            // 
            // txttotal
            // 
            this.txttotal.Location = new System.Drawing.Point(96, 208);
            this.txttotal.Name = "txttotal";
            this.txttotal.Size = new System.Drawing.Size(88, 20);
            this.txttotal.TabIndex = 9;
            this.txttotal.Text = "0";
            this.txttotal.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txttotal_KeyPress);
            // 
            // txtiva0
            // 
            this.txtiva0.Location = new System.Drawing.Point(96, 123);
            this.txtiva0.Name = "txtiva0";
            this.txtiva0.Size = new System.Drawing.Size(88, 20);
            this.txtiva0.TabIndex = 6;
            this.txtiva0.Text = "0";
            this.txtiva0.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtiva0_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(49, 182);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 16);
            this.label3.TabIndex = 91;
            this.label3.Text = "IVA:";
            // 
            // txtiva
            // 
            this.txtiva.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtiva.Location = new System.Drawing.Point(96, 179);
            this.txtiva.Name = "txtiva";
            this.txtiva.Size = new System.Drawing.Size(88, 22);
            this.txtiva.TabIndex = 8;
            this.txtiva.Text = "0";
            this.txtiva.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtiva_KeyPress);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(36, 212);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(52, 16);
            this.label27.TabIndex = 4;
            this.label27.Text = "TOTAL";
            // 
            // txtsub12
            // 
            this.txtsub12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.txtsub12.ForeColor = System.Drawing.Color.Black;
            this.txtsub12.Location = new System.Drawing.Point(96, 152);
            this.txtsub12.Name = "txtsub12";
            this.txtsub12.Size = new System.Drawing.Size(88, 21);
            this.txtsub12.TabIndex = 7;
            this.txtsub12.Text = "0";
            this.txtsub12.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtsub12_KeyPress);
            // 
            // txtautorizacion
            // 
            this.txtautorizacion.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtautorizacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtautorizacion.ForeColor = System.Drawing.Color.Black;
            this.txtautorizacion.Location = new System.Drawing.Point(96, 71);
            this.txtautorizacion.Name = "txtautorizacion";
            this.txtautorizacion.Size = new System.Drawing.Size(219, 20);
            this.txtautorizacion.TabIndex = 4;
            this.txtautorizacion.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // txtcodigo
            // 
            this.txtcodigo.Location = new System.Drawing.Point(291, 268);
            this.txtcodigo.Name = "txtcodigo";
            this.txtcodigo.Size = new System.Drawing.Size(66, 20);
            this.txtcodigo.TabIndex = 2;
            this.txtcodigo.Visible = false;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(243, 268);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(20, 13);
            this.label11.TabIndex = 0;
            this.label11.Text = "iD:";
            this.label11.Visible = false;
            // 
            // txtfactura
            // 
            this.txtfactura.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtfactura.Location = new System.Drawing.Point(96, 40);
            this.txtfactura.MaxLength = 100;
            this.txtfactura.Name = "txtfactura";
            this.txtfactura.Size = new System.Drawing.Size(219, 20);
            this.txtfactura.TabIndex = 3;
            this.txtfactura.Text = " ";
            this.txtfactura.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(16, 71);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(68, 13);
            this.label23.TabIndex = 55;
            this.label23.Text = "Autorizacion:";
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(84, 25);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.Size = new System.Drawing.Size(506, 510);
            this.dataGridView2.TabIndex = 80;
            // 
            // textBox1
            // 
            this.textBox1.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox1.Location = new System.Drawing.Point(12, 280);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(66, 20);
            this.textBox1.TabIndex = 95;
            this.textBox1.Text = "01/05/2015";
            // 
            // textBox2
            // 
            this.textBox2.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.textBox2.Location = new System.Drawing.Point(12, 306);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(66, 20);
            this.textBox2.TabIndex = 96;
            this.textBox2.Text = "31/05/2015";
            // 
            // button5
            // 
            this.button5.Image = ((System.Drawing.Image)(resources.GetObject("button5.Image")));
            this.button5.Location = new System.Drawing.Point(12, 206);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(53, 54);
            this.button5.TabIndex = 11;
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Image = global::RaposoFact.Properties.Resources.delete1;
            this.button4.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button4.Location = new System.Drawing.Point(12, 142);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(53, 60);
            this.button4.TabIndex = 99;
            this.button4.Text = "Eliminar";
            this.button4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button4.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            this.button3.Image = global::RaposoFact.Properties.Resources.vcard_edit;
            this.button3.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.button3.Location = new System.Drawing.Point(12, 77);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(53, 59);
            this.button3.TabIndex = 98;
            this.button3.Text = "Editar";
            this.button3.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.button3.UseVisualStyleBackColor = true;
            // 
            // btnguardar
            // 
            this.btnguardar.Image = global::RaposoFact.Properties.Resources.save;
            this.btnguardar.ImageAlign = System.Drawing.ContentAlignment.TopCenter;
            this.btnguardar.Location = new System.Drawing.Point(12, 13);
            this.btnguardar.Name = "btnguardar";
            this.btnguardar.Size = new System.Drawing.Size(53, 58);
            this.btnguardar.TabIndex = 97;
            this.btnguardar.Text = "Guardar";
            this.btnguardar.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            this.btnguardar.UseVisualStyleBackColor = true;
            this.btnguardar.Click += new System.EventHandler(this.btnguardar_Click);
            // 
            // Factura_compras
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1090, 562);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.btnguardar);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.button5);
            this.Name = "Factura_compras";
            this.Text = "Factura_compras";
            this.Load += new System.EventHandler(this.Factura_compras_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnproducto;
        private System.Windows.Forms.Button btncliente;
        private System.Windows.Forms.TextBox txtfono;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox txtdireccion;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtidcliente;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtbuscar;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtfechacaducidad;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtfecha;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.TextBox txtautorizacion;
        private System.Windows.Forms.TextBox txtcodigo;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtfactura;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TextBox txtsub12;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.TextBox txtiva;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtiva0;
        private System.Windows.Forms.TextBox txttotal;
        private System.Windows.Forms.TextBox txtemail;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private CrtRepstock0 CrtRepstock01;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button btnguardar;
    }
}