﻿namespace RaposoFact
{
    partial class Productos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtnumunidades = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtbuscar = new System.Windows.Forms.TextBox();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txtid = new System.Windows.Forms.TextBox();
            this.txtganancia = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtcosto = new System.Windows.Forms.TextBox();
            this.txtgastos = new System.Windows.Forms.TextBox();
            this.cmbtipoiva = new System.Windows.Forms.ComboBox();
            this.btndescartar = new System.Windows.Forms.Button();
            this.cmbtipocompra = new System.Windows.Forms.ComboBox();
            this.btnguardar = new System.Windows.Forms.Button();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.txtcodbar = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.txtdetalle = new System.Windows.Forms.TextBox();
            this.btneditar = new System.Windows.Forms.Button();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txtstock = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btncalcularprecio = new System.Windows.Forms.Button();
            this.txtpvp = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btgnnuevo = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(8, 81);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(178, 21);
            this.comboBox3.TabIndex = 105;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(19, 65);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(58, 13);
            this.label12.TabIndex = 104;
            this.label12.Text = "Subfamilia:";
            // 
            // txtnumunidades
            // 
            this.txtnumunidades.Location = new System.Drawing.Point(99, 148);
            this.txtnumunidades.MaxLength = 4;
            this.txtnumunidades.Name = "txtnumunidades";
            this.txtnumunidades.Size = new System.Drawing.Size(109, 20);
            this.txtnumunidades.TabIndex = 2;
            this.txtnumunidades.Text = "1";
            this.txtnumunidades.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtnumunidades_KeyPress);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(23, 148);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(65, 13);
            this.label7.TabIndex = 103;
            this.label7.Text = "# Unidades:";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Khaki;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.txtbuscar);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Location = new System.Drawing.Point(10, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(696, 43);
            this.panel1.TabIndex = 38;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(632, 9);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(21, 20);
            this.button1.TabIndex = 32;
            this.button1.Text = "::";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Khaki;
            this.label2.Location = new System.Drawing.Point(168, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(63, 13);
            this.label2.TabIndex = 31;
            this.label2.Text = "Descripcion";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Khaki;
            this.label1.Location = new System.Drawing.Point(9, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(40, 13);
            this.label1.TabIndex = 30;
            this.label1.Text = "Codigo";
            // 
            // txtbuscar
            // 
            this.txtbuscar.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtbuscar.Location = new System.Drawing.Point(237, 9);
            this.txtbuscar.Name = "txtbuscar";
            this.txtbuscar.Size = new System.Drawing.Size(379, 20);
            this.txtbuscar.TabIndex = 40;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(55, 10);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(107, 20);
            this.textBox1.TabIndex = 28;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(67, 11);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(19, 13);
            this.label8.TabIndex = 102;
            this.label8.Text = "Id:";
            // 
            // txtid
            // 
            this.txtid.Location = new System.Drawing.Point(108, 11);
            this.txtid.Name = "txtid";
            this.txtid.Size = new System.Drawing.Size(100, 20);
            this.txtid.TabIndex = 101;
            this.txtid.TextChanged += new System.EventHandler(this.txtid_TextChanged);
            this.txtid.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtid_KeyPress);
            // 
            // txtganancia
            // 
            this.txtganancia.Location = new System.Drawing.Point(272, 171);
            this.txtganancia.Name = "txtganancia";
            this.txtganancia.Size = new System.Drawing.Size(71, 20);
            this.txtganancia.TabIndex = 5;
            this.txtganancia.Text = "40";
            this.txtganancia.TextChanged += new System.EventHandler(this.txtganancia_TextChanged);
            this.txtganancia.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtganancia_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(202, 174);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 13);
            this.label3.TabIndex = 100;
            this.label3.Text = "%Ganancia:";
            // 
            // txtcosto
            // 
            this.txtcosto.Location = new System.Drawing.Point(272, 145);
            this.txtcosto.MaxLength = 8;
            this.txtcosto.Name = "txtcosto";
            this.txtcosto.Size = new System.Drawing.Size(71, 20);
            this.txtcosto.TabIndex = 3;
            this.txtcosto.TextChanged += new System.EventHandler(this.txtcosto_TextChanged);
            this.txtcosto.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtcosto_KeyPress);
            // 
            // txtgastos
            // 
            this.txtgastos.Location = new System.Drawing.Point(99, 174);
            this.txtgastos.MaxLength = 6;
            this.txtgastos.Name = "txtgastos";
            this.txtgastos.Size = new System.Drawing.Size(52, 20);
            this.txtgastos.TabIndex = 4;
            this.txtgastos.Text = "0";
            this.txtgastos.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtgastos_KeyPress);
            // 
            // cmbtipoiva
            // 
            this.cmbtipoiva.FormattingEnabled = true;
            this.cmbtipoiva.Items.AddRange(new object[] {
            "0",
            "12"});
            this.cmbtipoiva.Location = new System.Drawing.Point(99, 200);
            this.cmbtipoiva.Name = "cmbtipoiva";
            this.cmbtipoiva.Size = new System.Drawing.Size(78, 21);
            this.cmbtipoiva.TabIndex = 6;
            this.cmbtipoiva.SelectedIndexChanged += new System.EventHandler(this.cmbtipoiva_SelectedIndexChanged);
            // 
            // btndescartar
            // 
            this.btndescartar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btndescartar.Location = new System.Drawing.Point(10, 183);
            this.btndescartar.Name = "btndescartar";
            this.btndescartar.Size = new System.Drawing.Size(80, 33);
            this.btndescartar.TabIndex = 40;
            this.btndescartar.Text = "Descartar";
            this.btndescartar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btndescartar.UseVisualStyleBackColor = true;
            this.btndescartar.Click += new System.EventHandler(this.btndescartar_Click);
            // 
            // cmbtipocompra
            // 
            this.cmbtipocompra.FormattingEnabled = true;
            this.cmbtipocompra.Items.AddRange(new object[] {
            "Nota venta",
            "Factura"});
            this.cmbtipocompra.Location = new System.Drawing.Point(272, 199);
            this.cmbtipocompra.Name = "cmbtipocompra";
            this.cmbtipocompra.Size = new System.Drawing.Size(71, 21);
            this.cmbtipocompra.TabIndex = 7;
            // 
            // btnguardar
            // 
            this.btnguardar.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnguardar.Location = new System.Drawing.Point(10, 106);
            this.btnguardar.Name = "btnguardar";
            this.btnguardar.Size = new System.Drawing.Size(82, 33);
            this.btnguardar.TabIndex = 10;
            this.btnguardar.Text = "Guardar  ";
            this.btnguardar.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnguardar.UseVisualStyleBackColor = true;
            this.btnguardar.Click += new System.EventHandler(this.btnguardar_Click);
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(108, 37);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(143, 21);
            this.comboBox1.TabIndex = 81;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.LightSteelBlue;
            this.panel2.Controls.Add(this.txtcodbar);
            this.panel2.Controls.Add(this.textBox2);
            this.panel2.Controls.Add(this.txtdetalle);
            this.panel2.Controls.Add(this.comboBox3);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.txtnumunidades);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.txtid);
            this.panel2.Controls.Add(this.txtganancia);
            this.panel2.Controls.Add(this.label3);
            this.panel2.Controls.Add(this.txtcosto);
            this.panel2.Controls.Add(this.txtgastos);
            this.panel2.Controls.Add(this.cmbtipocompra);
            this.panel2.Controls.Add(this.cmbtipoiva);
            this.panel2.Controls.Add(this.comboBox1);
            this.panel2.Controls.Add(this.label17);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.txtstock);
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.btncalcularprecio);
            this.panel2.Controls.Add(this.txtpvp);
            this.panel2.Location = new System.Drawing.Point(609, 61);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(348, 482);
            this.panel2.TabIndex = 1;
            // 
            // txtcodbar
            // 
            this.txtcodbar.Location = new System.Drawing.Point(192, 81);
            this.txtcodbar.Name = "txtcodbar";
            this.txtcodbar.Size = new System.Drawing.Size(118, 20);
            this.txtcodbar.TabIndex = 1;
            this.txtcodbar.TextChanged += new System.EventHandler(this.txtcodbar_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(157, 174);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(51, 20);
            this.textBox2.TabIndex = 106;
            // 
            // txtdetalle
            // 
            this.txtdetalle.CharacterCasing = System.Windows.Forms.CharacterCasing.Upper;
            this.txtdetalle.Location = new System.Drawing.Point(8, 122);
            this.txtdetalle.Name = "txtdetalle";
            this.txtdetalle.Size = new System.Drawing.Size(330, 20);
            this.txtdetalle.TabIndex = 0;
            this.txtdetalle.TextChanged += new System.EventHandler(this.txtdetalle_TextChanged_1);
            // 
            // btneditar
            // 
            this.btneditar.Location = new System.Drawing.Point(10, 144);
            this.btneditar.Name = "btneditar";
            this.btneditar.Size = new System.Drawing.Size(75, 33);
            this.btneditar.TabIndex = 44;
            this.btneditar.Text = "Editar";
            this.btneditar.UseVisualStyleBackColor = true;
            this.btneditar.Click += new System.EventHandler(this.btneditar_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(35, 174);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(53, 13);
            this.label17.TabIndex = 99;
            this.label17.Text = "Gastos T:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(197, 205);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(69, 13);
            this.label16.TabIndex = 98;
            this.label16.Text = "Tipo compra:";
            // 
            // txtstock
            // 
            this.txtstock.Location = new System.Drawing.Point(272, 224);
            this.txtstock.MaxLength = 4;
            this.txtstock.Name = "txtstock";
            this.txtstock.Size = new System.Drawing.Size(71, 20);
            this.txtstock.TabIndex = 9;
            this.txtstock.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtstock_KeyPress);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(229, 152);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(37, 13);
            this.label15.TabIndex = 97;
            this.label15.Text = "Costo:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(5, 106);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(66, 13);
            this.label14.TabIndex = 96;
            this.label14.Text = "Descripción:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(228, 229);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(38, 13);
            this.label13.TabIndex = 95;
            this.label13.Text = "Stock:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(14, 205);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 13);
            this.label6.TabIndex = 94;
            this.label6.Text = "Tipo de I.V.A.:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(54, 229);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 13);
            this.label5.TabIndex = 93;
            this.label5.Text = "P.V.P.";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(57, 45);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 13);
            this.label4.TabIndex = 92;
            this.label4.Text = "Familia:";
            // 
            // btncalcularprecio
            // 
            this.btncalcularprecio.Location = new System.Drawing.Point(181, 228);
            this.btncalcularprecio.Name = "btncalcularprecio";
            this.btncalcularprecio.Size = new System.Drawing.Size(20, 18);
            this.btncalcularprecio.TabIndex = 8;
            this.btncalcularprecio.Text = "::";
            this.btncalcularprecio.UseVisualStyleBackColor = true;
            this.btncalcularprecio.Click += new System.EventHandler(this.btncalcularprecio_Click);
            // 
            // txtpvp
            // 
            this.txtpvp.Location = new System.Drawing.Point(99, 227);
            this.txtpvp.Name = "txtpvp";
            this.txtpvp.ReadOnly = true;
            this.txtpvp.Size = new System.Drawing.Size(100, 20);
            this.txtpvp.TabIndex = 91;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCellsExceptHeader;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(104, 61);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(499, 499);
            this.dataGridView1.TabIndex = 45;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.Click += new System.EventHandler(this.dataGridView1_Click);
            // 
            // btgnnuevo
            // 
            this.btgnnuevo.Location = new System.Drawing.Point(10, 72);
            this.btgnnuevo.Name = "btgnnuevo";
            this.btgnnuevo.Size = new System.Drawing.Size(75, 33);
            this.btgnnuevo.TabIndex = 41;
            this.btgnnuevo.Text = "Nuevo";
            this.btgnnuevo.UseVisualStyleBackColor = true;
            this.btgnnuevo.Click += new System.EventHandler(this.btgnnuevo_Click);
            // 
            // Productos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(967, 578);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btnguardar);
            this.Controls.Add(this.btgnnuevo);
            this.Controls.Add(this.btndescartar);
            this.Controls.Add(this.btneditar);
            this.Name = "Productos";
            this.Text = "Productos";
            this.Load += new System.EventHandler(this.Productos_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtnumunidades;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtbuscar;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtid;
        private System.Windows.Forms.TextBox txtganancia;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtcosto;
        private System.Windows.Forms.TextBox txtgastos;
        private System.Windows.Forms.ComboBox cmbtipoiva;
        private System.Windows.Forms.Button btndescartar;
        private System.Windows.Forms.ComboBox cmbtipocompra;
        private System.Windows.Forms.Button btnguardar;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtstock;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btncalcularprecio;
        private System.Windows.Forms.TextBox txtpvp;
        private System.Windows.Forms.Button btneditar;
        private System.Windows.Forms.TextBox txtdetalle;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox txtcodbar;
        private System.Windows.Forms.Button btgnnuevo;
    }
}