﻿namespace RaposoFact
{
    partial class MDIParent1
    {
        /// <summary>
        /// Variable del diseñador requerida.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén utilizando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben eliminar; false en caso contrario, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido del método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MDIParent1));
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.mantenimientoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.familiaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.artículosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.clientesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.recargasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.deudasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tRXToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.proveedorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.películasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ingresarToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buscarYVenderToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.anularVentaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ventasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.facturaciónToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.notaDeVentaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pruebaFToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.recargasToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.reportesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lIstaPreciosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.notaVentaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cNBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.recargasToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.inicialToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aperturaDeCajaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.retirarEfectivoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.retirarEfectivoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.ingresosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.detallesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.verTotalesDeCajaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.cerrarSesiónToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.respaldosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bdToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pruebaToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.contentsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.indexToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator8 = new System.Windows.Forms.ToolStripSeparator();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.comprasToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.comprasToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(86)))), ((int)(((byte)(197)))), ((int)(((byte)(73)))));
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mantenimientoToolStripMenuItem,
            this.películasToolStripMenuItem,
            this.ventasToolStripMenuItem,
            this.reportesToolStripMenuItem,
            this.inicialToolStripMenuItem,
            this.respaldosToolStripMenuItem,
            this.helpMenu,
            this.comprasToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(604, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            // 
            // mantenimientoToolStripMenuItem
            // 
            this.mantenimientoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.familiaToolStripMenuItem,
            this.artículosToolStripMenuItem,
            this.clientesToolStripMenuItem,
            this.recargasToolStripMenuItem,
            this.deudasToolStripMenuItem,
            this.tRXToolStripMenuItem,
            this.proveedorToolStripMenuItem});
            this.mantenimientoToolStripMenuItem.Name = "mantenimientoToolStripMenuItem";
            this.mantenimientoToolStripMenuItem.Size = new System.Drawing.Size(101, 20);
            this.mantenimientoToolStripMenuItem.Text = "&Mantenimiento";
            // 
            // familiaToolStripMenuItem
            // 
            this.familiaToolStripMenuItem.Name = "familiaToolStripMenuItem";
            this.familiaToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.familiaToolStripMenuItem.Text = "&Familia";
            this.familiaToolStripMenuItem.Click += new System.EventHandler(this.familiaToolStripMenuItem_Click);
            // 
            // artículosToolStripMenuItem
            // 
            this.artículosToolStripMenuItem.Name = "artículosToolStripMenuItem";
            this.artículosToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.artículosToolStripMenuItem.Text = "&Artículos";
            this.artículosToolStripMenuItem.Click += new System.EventHandler(this.artículosToolStripMenuItem_Click);
            // 
            // clientesToolStripMenuItem
            // 
            this.clientesToolStripMenuItem.Name = "clientesToolStripMenuItem";
            this.clientesToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.clientesToolStripMenuItem.Text = "&Clientes";
            this.clientesToolStripMenuItem.Click += new System.EventHandler(this.clientesToolStripMenuItem_Click);
            // 
            // recargasToolStripMenuItem
            // 
            this.recargasToolStripMenuItem.Name = "recargasToolStripMenuItem";
            this.recargasToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.recargasToolStripMenuItem.Text = "&Recargas";
            this.recargasToolStripMenuItem.Click += new System.EventHandler(this.recargasToolStripMenuItem_Click);
            // 
            // deudasToolStripMenuItem
            // 
            this.deudasToolStripMenuItem.Name = "deudasToolStripMenuItem";
            this.deudasToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.deudasToolStripMenuItem.Text = "&Deudas";
            this.deudasToolStripMenuItem.Click += new System.EventHandler(this.deudasToolStripMenuItem_Click);
            // 
            // tRXToolStripMenuItem
            // 
            this.tRXToolStripMenuItem.Name = "tRXToolStripMenuItem";
            this.tRXToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.tRXToolStripMenuItem.Text = "TRX";
            this.tRXToolStripMenuItem.Click += new System.EventHandler(this.tRXToolStripMenuItem_Click);
            // 
            // proveedorToolStripMenuItem
            // 
            this.proveedorToolStripMenuItem.Name = "proveedorToolStripMenuItem";
            this.proveedorToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.proveedorToolStripMenuItem.Text = "&Proveedor";
            this.proveedorToolStripMenuItem.Click += new System.EventHandler(this.proveedorToolStripMenuItem_Click);
            // 
            // películasToolStripMenuItem
            // 
            this.películasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ingresarToolStripMenuItem,
            this.buscarYVenderToolStripMenuItem,
            this.anularVentaToolStripMenuItem});
            this.películasToolStripMenuItem.Name = "películasToolStripMenuItem";
            this.películasToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.películasToolStripMenuItem.Text = "&Películas";
            // 
            // ingresarToolStripMenuItem
            // 
            this.ingresarToolStripMenuItem.Name = "ingresarToolStripMenuItem";
            this.ingresarToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.ingresarToolStripMenuItem.Text = "&Ingresar";
            this.ingresarToolStripMenuItem.Click += new System.EventHandler(this.ingresarToolStripMenuItem_Click);
            // 
            // buscarYVenderToolStripMenuItem
            // 
            this.buscarYVenderToolStripMenuItem.Name = "buscarYVenderToolStripMenuItem";
            this.buscarYVenderToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.buscarYVenderToolStripMenuItem.Text = "&Buscar y Vender";
            this.buscarYVenderToolStripMenuItem.Click += new System.EventHandler(this.buscarYVenderToolStripMenuItem_Click);
            // 
            // anularVentaToolStripMenuItem
            // 
            this.anularVentaToolStripMenuItem.Name = "anularVentaToolStripMenuItem";
            this.anularVentaToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.anularVentaToolStripMenuItem.Text = "&Anular Venta";
            this.anularVentaToolStripMenuItem.Click += new System.EventHandler(this.anularVentaToolStripMenuItem_Click);
            // 
            // ventasToolStripMenuItem
            // 
            this.ventasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.facturaciónToolStripMenuItem,
            this.notaDeVentaToolStripMenuItem,
            this.pruebaFToolStripMenuItem,
            this.recargasToolStripMenuItem2});
            this.ventasToolStripMenuItem.Name = "ventasToolStripMenuItem";
            this.ventasToolStripMenuItem.Size = new System.Drawing.Size(54, 20);
            this.ventasToolStripMenuItem.Text = "&Ventas";
            // 
            // facturaciónToolStripMenuItem
            // 
            this.facturaciónToolStripMenuItem.Name = "facturaciónToolStripMenuItem";
            this.facturaciónToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.facturaciónToolStripMenuItem.Text = "&Facturación";
            this.facturaciónToolStripMenuItem.Click += new System.EventHandler(this.facturaciónToolStripMenuItem_Click);
            // 
            // notaDeVentaToolStripMenuItem
            // 
            this.notaDeVentaToolStripMenuItem.Name = "notaDeVentaToolStripMenuItem";
            this.notaDeVentaToolStripMenuItem.ShortcutKeys = System.Windows.Forms.Keys.F4;
            this.notaDeVentaToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.notaDeVentaToolStripMenuItem.Text = "&Nota de Venta";
            this.notaDeVentaToolStripMenuItem.Click += new System.EventHandler(this.notaDeVentaToolStripMenuItem_Click);
            // 
            // pruebaFToolStripMenuItem
            // 
            this.pruebaFToolStripMenuItem.Name = "pruebaFToolStripMenuItem";
            this.pruebaFToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.pruebaFToolStripMenuItem.Text = "Prueba F";
            this.pruebaFToolStripMenuItem.Click += new System.EventHandler(this.pruebaFToolStripMenuItem_Click);
            // 
            // recargasToolStripMenuItem2
            // 
            this.recargasToolStripMenuItem2.Name = "recargasToolStripMenuItem2";
            this.recargasToolStripMenuItem2.Size = new System.Drawing.Size(168, 22);
            this.recargasToolStripMenuItem2.Text = "Recargas";
            this.recargasToolStripMenuItem2.Click += new System.EventHandler(this.recargasToolStripMenuItem2_Click);
            // 
            // reportesToolStripMenuItem
            // 
            this.reportesToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lIstaPreciosToolStripMenuItem,
            this.notaVentaToolStripMenuItem,
            this.cNBToolStripMenuItem,
            this.recargasToolStripMenuItem1});
            this.reportesToolStripMenuItem.Name = "reportesToolStripMenuItem";
            this.reportesToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.reportesToolStripMenuItem.Text = "&Reportes";
            // 
            // lIstaPreciosToolStripMenuItem
            // 
            this.lIstaPreciosToolStripMenuItem.Name = "lIstaPreciosToolStripMenuItem";
            this.lIstaPreciosToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.lIstaPreciosToolStripMenuItem.Text = "&LIsta Precios";
            this.lIstaPreciosToolStripMenuItem.Click += new System.EventHandler(this.lIstaPreciosToolStripMenuItem_Click);
            // 
            // notaVentaToolStripMenuItem
            // 
            this.notaVentaToolStripMenuItem.Name = "notaVentaToolStripMenuItem";
            this.notaVentaToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.notaVentaToolStripMenuItem.Text = "&Nota Venta";
            this.notaVentaToolStripMenuItem.Click += new System.EventHandler(this.notaVentaToolStripMenuItem_Click);
            // 
            // cNBToolStripMenuItem
            // 
            this.cNBToolStripMenuItem.Name = "cNBToolStripMenuItem";
            this.cNBToolStripMenuItem.ShortcutKeyDisplayString = "F2";
            this.cNBToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.cNBToolStripMenuItem.Text = "&CNB";
            this.cNBToolStripMenuItem.Click += new System.EventHandler(this.cNBToolStripMenuItem_Click);
            // 
            // recargasToolStripMenuItem1
            // 
            this.recargasToolStripMenuItem1.Name = "recargasToolStripMenuItem1";
            this.recargasToolStripMenuItem1.Size = new System.Drawing.Size(173, 22);
            this.recargasToolStripMenuItem1.Text = "&Resumen Recargas";
            this.recargasToolStripMenuItem1.Click += new System.EventHandler(this.recargasToolStripMenuItem1_Click);
            // 
            // inicialToolStripMenuItem
            // 
            this.inicialToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aperturaDeCajaToolStripMenuItem,
            this.retirarEfectivoToolStripMenuItem,
            this.verTotalesDeCajaToolStripMenuItem,
            this.cerrarSesiónToolStripMenuItem});
            this.inicialToolStripMenuItem.Name = "inicialToolStripMenuItem";
            this.inicialToolStripMenuItem.Size = new System.Drawing.Size(53, 20);
            this.inicialToolStripMenuItem.Text = "&Cajero";
            // 
            // aperturaDeCajaToolStripMenuItem
            // 
            this.aperturaDeCajaToolStripMenuItem.Name = "aperturaDeCajaToolStripMenuItem";
            this.aperturaDeCajaToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.aperturaDeCajaToolStripMenuItem.Text = "&Apertura de Caja";
            this.aperturaDeCajaToolStripMenuItem.Click += new System.EventHandler(this.aperturaDeCajaToolStripMenuItem_Click);
            // 
            // retirarEfectivoToolStripMenuItem
            // 
            this.retirarEfectivoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.retirarEfectivoToolStripMenuItem1,
            this.ingresosToolStripMenuItem,
            this.detallesToolStripMenuItem});
            this.retirarEfectivoToolStripMenuItem.Name = "retirarEfectivoToolStripMenuItem";
            this.retirarEfectivoToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.retirarEfectivoToolStripMenuItem.Text = "&Movimientos";
            this.retirarEfectivoToolStripMenuItem.Click += new System.EventHandler(this.retirarEfectivoToolStripMenuItem_Click);
            // 
            // retirarEfectivoToolStripMenuItem1
            // 
            this.retirarEfectivoToolStripMenuItem1.Name = "retirarEfectivoToolStripMenuItem1";
            this.retirarEfectivoToolStripMenuItem1.Size = new System.Drawing.Size(163, 22);
            this.retirarEfectivoToolStripMenuItem1.Text = "&Retirar Efectivo";
            this.retirarEfectivoToolStripMenuItem1.Click += new System.EventHandler(this.retirarEfectivoToolStripMenuItem1_Click);
            // 
            // ingresosToolStripMenuItem
            // 
            this.ingresosToolStripMenuItem.Name = "ingresosToolStripMenuItem";
            this.ingresosToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.ingresosToolStripMenuItem.Text = "&Ingresos Efectivo";
            this.ingresosToolStripMenuItem.Click += new System.EventHandler(this.ingresosToolStripMenuItem_Click);
            // 
            // detallesToolStripMenuItem
            // 
            this.detallesToolStripMenuItem.Name = "detallesToolStripMenuItem";
            this.detallesToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.detallesToolStripMenuItem.Text = "&Detalles";
            this.detallesToolStripMenuItem.Click += new System.EventHandler(this.detallesToolStripMenuItem_Click);
            // 
            // verTotalesDeCajaToolStripMenuItem
            // 
            this.verTotalesDeCajaToolStripMenuItem.Name = "verTotalesDeCajaToolStripMenuItem";
            this.verTotalesDeCajaToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.verTotalesDeCajaToolStripMenuItem.Text = "&Ver Totales de Caja";
            this.verTotalesDeCajaToolStripMenuItem.Click += new System.EventHandler(this.verTotalesDeCajaToolStripMenuItem_Click);
            // 
            // cerrarSesiónToolStripMenuItem
            // 
            this.cerrarSesiónToolStripMenuItem.Name = "cerrarSesiónToolStripMenuItem";
            this.cerrarSesiónToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.cerrarSesiónToolStripMenuItem.Text = "&Cerrar Sesión";
            // 
            // respaldosToolStripMenuItem
            // 
            this.respaldosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bdToolStripMenuItem,
            this.pruebaToolStripMenuItem});
            this.respaldosToolStripMenuItem.Name = "respaldosToolStripMenuItem";
            this.respaldosToolStripMenuItem.Size = new System.Drawing.Size(72, 20);
            this.respaldosToolStripMenuItem.Text = "&Respaldos";
            // 
            // bdToolStripMenuItem
            // 
            this.bdToolStripMenuItem.Name = "bdToolStripMenuItem";
            this.bdToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.bdToolStripMenuItem.Text = "&Bd";
            this.bdToolStripMenuItem.Click += new System.EventHandler(this.bdToolStripMenuItem_Click);
            // 
            // pruebaToolStripMenuItem
            // 
            this.pruebaToolStripMenuItem.Name = "pruebaToolStripMenuItem";
            this.pruebaToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.pruebaToolStripMenuItem.Text = "prueba";
            this.pruebaToolStripMenuItem.Click += new System.EventHandler(this.pruebaToolStripMenuItem_Click);
            // 
            // helpMenu
            // 
            this.helpMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.contentsToolStripMenuItem,
            this.indexToolStripMenuItem,
            this.searchToolStripMenuItem,
            this.toolStripSeparator8,
            this.aboutToolStripMenuItem});
            this.helpMenu.Name = "helpMenu";
            this.helpMenu.Size = new System.Drawing.Size(53, 20);
            this.helpMenu.Text = "Ay&uda";
            // 
            // contentsToolStripMenuItem
            // 
            this.contentsToolStripMenuItem.Name = "contentsToolStripMenuItem";
            this.contentsToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.F1)));
            this.contentsToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.contentsToolStripMenuItem.Text = "&Contenido";
            this.contentsToolStripMenuItem.Click += new System.EventHandler(this.contentsToolStripMenuItem_Click);
            // 
            // indexToolStripMenuItem
            // 
            this.indexToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("indexToolStripMenuItem.Image")));
            this.indexToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.indexToolStripMenuItem.Name = "indexToolStripMenuItem";
            this.indexToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.indexToolStripMenuItem.Text = "&Índice";
            // 
            // searchToolStripMenuItem
            // 
            this.searchToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("searchToolStripMenuItem.Image")));
            this.searchToolStripMenuItem.ImageTransparentColor = System.Drawing.Color.Black;
            this.searchToolStripMenuItem.Name = "searchToolStripMenuItem";
            this.searchToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.searchToolStripMenuItem.Text = "&Buscar";
            // 
            // toolStripSeparator8
            // 
            this.toolStripSeparator8.Name = "toolStripSeparator8";
            this.toolStripSeparator8.Size = new System.Drawing.Size(173, 6);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(176, 22);
            this.aboutToolStripMenuItem.Text = "&Acerca de... ...";
            // 
            // comprasToolStripMenuItem
            // 
            this.comprasToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.comprasToolStripMenuItem1});
            this.comprasToolStripMenuItem.Name = "comprasToolStripMenuItem";
            this.comprasToolStripMenuItem.Size = new System.Drawing.Size(67, 20);
            this.comprasToolStripMenuItem.Text = "&Compras";
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 523);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(604, 22);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "StatusStrip";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(42, 17);
            this.toolStripStatusLabel.Text = "Estado";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(509, 0);
            this.textBox1.Name = "textBox1";
            this.textBox1.ReadOnly = true;
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 4;
            // 
            // comprasToolStripMenuItem1
            // 
            this.comprasToolStripMenuItem1.Name = "comprasToolStripMenuItem1";
            this.comprasToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.comprasToolStripMenuItem1.Text = "&Compras ";
            this.comprasToolStripMenuItem1.Click += new System.EventHandler(this.comprasToolStripMenuItem1_Click);
            // 
            // MDIParent1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::RaposoFact.Properties.Resources.fonMDI;
            this.ClientSize = new System.Drawing.Size(604, 545);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.menuStrip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "MDIParent1";
            this.Text = "RAPOSO";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion


        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator8;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpMenu;
        private System.Windows.Forms.ToolStripMenuItem contentsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem indexToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchToolStripMenuItem;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.ToolStripMenuItem mantenimientoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem familiaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem artículosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem películasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ingresarToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buscarYVenderToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem anularVentaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ventasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem facturaciónToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem notaDeVentaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lIstaPreciosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem notaVentaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cNBToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inicialToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aperturaDeCajaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem retirarEfectivoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem verTotalesDeCajaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem cerrarSesiónToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem detallesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem retirarEfectivoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem clientesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem recargasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem recargasToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem deudasToolStripMenuItem;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.ToolStripMenuItem respaldosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem bdToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ingresosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tRXToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pruebaToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pruebaFToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem recargasToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem proveedorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem comprasToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem comprasToolStripMenuItem1;
    }
}



