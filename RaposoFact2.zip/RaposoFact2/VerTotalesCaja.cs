﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace RaposoFact
{
    public partial class VerTotalesCaja : Form
    {
        Clases.ClsCaja caja = new Clases.ClsCaja();
        public VerTotalesCaja()
        {
            InitializeComponent();
        }
        private void cargartotalrecargas()
  {
      label6.Text = System.DateTime.Now.ToString();
     
      DataSet datos1;

      datos1 = caja.cargarTotalRecargas(Convert.ToDateTime(label6.Text));
      txtbwise.Text = datos1.Tables[0].Rows[0].ItemArray[1].ToString();
      txtpclaro.Text = datos1.Tables[0].Rows[0].ItemArray[2].ToString();
      txtxy.Text = datos1.Tables[0].Rows[0].ItemArray[0].ToString();
    

  }
        private void cargartotalrecargasIMPORTE()
        {
              try
            {
            label6.Text = System.DateTime.Now.ToString();

            DataSet datos1;

            datos1 = caja.cargarTotalRecargasIMPORTEs(Convert.ToDateTime(label6.Text));
            this.textBox3.Text = datos1.Tables[0].Rows[0].ItemArray[0].ToString();
            textBox2.Text = datos1.Tables[0].Rows[0].ItemArray[1].ToString();
            textBox1.Text = datos1.Tables[0].Rows[0].ItemArray[2].ToString();

            }
             catch
              { }
        }
        private void VerTotalesCaja_Load(object sender, EventArgs e)
        {
            try
            {
                label6.Text = System.DateTime.Now.ToString();
                DataSet datos;
                datos = caja.cargarTotalConsumo(Convert.ToDateTime(label6.Text));
                txtconsumo.Text = datos.Tables[0].Rows[0].ItemArray[0].ToString();
                caja.guardarvtotal(Convert.ToDateTime(label6.Text), Convert.ToDecimal(txtconsumo.Text));


                caja.cargarTotalCaja(Convert.ToDateTime(label6.Text));
                DataSet datos1;

                datos1 = caja.cargarTotalCaja(Convert.ToDateTime(label6.Text));
                txtcajainicial.Text = datos1.Tables[0].Rows[0].ItemArray[0].ToString();
                txtconsumo.Text = datos1.Tables[0].Rows[0].ItemArray[1].ToString();
                txtdepositos.Text = datos1.Tables[0].Rows[0].ItemArray[2].ToString();
                txtretiros.Text = datos1.Tables[0].Rows[0].ItemArray[3].ToString();
                txtsaldocaja.Text = datos1.Tables[0].Rows[0].ItemArray[4].ToString();

                cargartotalrecargas();
                cargartotalrecargasIMPORTE();
            }
            catch
            {
                DataSet datos1;
                datos1 = caja.cargarTotalCaja(Convert.ToDateTime(label6.Text));
                txtcajainicial.Text = datos1.Tables[0].Rows[0].ItemArray[0].ToString();
                txtconsumo.Text = "0";
                txtdepositos.Text = "0";
                txtretiros.Text = "0";
                txtsaldocaja.Text = "0";
                txtbwise.Text = "0";
                txtpclaro.Text = "0";
                txtxy.Text = "0";
                textBox3.Text = "0";
                textBox2.Text = "0";
                textBox1.Text = "0";

               
            }
            //txttotalg.Text = datos.Tables[0].Rows[0].ItemArray[0].ToString();
        }
    }
}
