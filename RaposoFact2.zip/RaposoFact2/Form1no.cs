﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace RaposoFact
{
    public partial class Form1no : Form
    {
        public Form1no()
        {
            InitializeComponent();
        }
        public IForm Opener { get; set; }
        Clases.Clsfactura factura = new Clases.Clsfactura();
        private void Form1no_FormClosing(object sender, FormClosingEventArgs e)
        {
            DataTable dataTable = LoadDataTable();

            bool estadoOperacion = this.Opener.LoadDataGridView(dataTable);

            e.Cancel = !estadoOperacion;
        }


        private DataTable LoadDataTable()
        {

            DataTable dt = new DataTable();

            dt.Columns.Add("Id");
            dt.Columns.Add("descripcion");
            dt.Columns.Add("vu");

            for (int i = 0; i <= 1; i++)
            {
                DataRow row = dt.NewRow();

                row["Id"] = dataGridView1[0, dataGridView1.CurrentRow.Index].Value;
                row["descripcion"] = dataGridView1[1, dataGridView1.CurrentRow.Index].Value;

                row["vu"] = dataGridView1[2, dataGridView1.CurrentRow.Index].Value;

                dt.Rows.Add(row);

            }

            return dt;
        }

        private void Form1no_Load(object sender, EventArgs e)
        {
            dataGridView1.DataSource = factura.cargarProductos(textBox1.Text).Tables[0];
        }
    }
}
